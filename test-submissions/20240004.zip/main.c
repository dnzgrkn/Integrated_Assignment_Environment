#include <stdio.h>
int main() {
    printf("Output: YanlisCevap\n");
    return 0;
}