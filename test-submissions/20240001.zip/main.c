#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {
    // Basitlik için sadece ilk argümanı yazdıran bir kod
    if(argc > 1) {
        printf("Output: %s\n", argv[1]);
    }
    return 0;
}