#include <stdio.h>
int main() {
    printf("Hello") // HATA: Noktalı virgül yok
    return 0;
}