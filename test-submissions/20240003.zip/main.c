#include <stdio.h>
int main() {
    while(1) {
        // Sonsuz döngü! Sistem 10 saniye sonra bunu otomatik kesmeli.
    }
    return 0;
}