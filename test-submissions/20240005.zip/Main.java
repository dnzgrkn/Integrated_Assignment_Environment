public class Main {
    public static void main(String[] args) {
        if(args.length > 0) {
            System.out.println("Output: " + args[0]);
        }
    }
}